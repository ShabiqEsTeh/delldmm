# Instagram Tools

## List Tool
- Auto Delete DM [delete_dm.php]

## Requirement

Get cookies instagram only requires [PHP](http://php.net/).  

## Installation via git

```
$ git clone https://github.com/yaelahan/instagram-tools
```
## Usage
```
$ cd instagram-tools
$ php {tool}.php
```
